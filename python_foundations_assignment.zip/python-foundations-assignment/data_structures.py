# Favorite Tools List
tools = ["Python", "Excel", "Power BI"]

print("Original List:", tools)

tools.append("Tableau")
print("After Adding:", tools)
