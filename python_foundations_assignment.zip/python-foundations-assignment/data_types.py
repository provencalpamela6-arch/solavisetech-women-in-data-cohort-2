# Personal Bio Generator
name = "Pamela"
age = 18
height = 1.75
favorite_tech_field = "Data Science"
is_student = True

print(f"Hello, my name is {name}. I am {age} years old, {height}m tall, and I love {favorite_tech_field}. Student Status: {is_student}")

# Type Checker
number = 10
price = 25.5
message = "Python"
status = True

print(type(number))
print(type(price))
print(type(message))
print(type(status))

# Data Conversion
integer_num = 50
float_num = 19.8
string_num = "100"

print(str(integer_num))
print(int(float_num))
print(int(string_num))

# User Information
user_name = input("Enter your name: ")
user_age = input("Enter your age: ")
country = input("Enter your country: ")

print(f"Welcome {user_name}! You are {user_age} years old and you are from {country}.")

# Temperature Converter
celsius = float(input("Enter temperature in Celsius: "))
fahrenheit = (celsius * 9/5) + 32

print(f"Temperature in Fahrenheit: {fahrenheit}")
